-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 09, 2017 at 03:24 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `StudentSystem`
--
CREATE DATABASE IF NOT EXISTS `StudentSystem` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `StudentSystem`;

-- --------------------------------------------------------

--
-- Table structure for table `degree`
--

CREATE TABLE `degree` (
  `id` int(11) NOT NULL,
  `degree` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `degree`
--

INSERT INTO `degree` (`id`, `degree`) VALUES
(1, 'доц.'),
(2, 'проф.');

-- --------------------------------------------------------

--
-- Table structure for table `discipline`
--

CREATE TABLE `discipline` (
  `id` int(11) NOT NULL,
  `discipline` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discipline`
--

INSERT INTO `discipline` (`id`, `discipline`) VALUES
(1, 'Увод в компютърните науки'),
(2, 'Математически анализ'),
(3, 'Основи на програмирането'),
(4, 'Линейна алгебра'),
(5, 'Организация на компютърната система'),
(6, 'Програмиране на С++'),
(7, 'Геометрия'),
(8, 'Дискретни структури'),
(9, 'Компютърна алгебра'),
(10, 'Алгоритми и структури от данни');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `id_lecturer` int(11) NOT NULL,
  `id_discipline` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `room` varchar(256) NOT NULL,
  `max_students` int(11) NOT NULL,
  `id_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `id_lecturer`, `id_discipline`, `date_time`, `room`, `max_students`, `id_type`) VALUES
(1, 1, 1, '2018-01-07 08:00:00', '102А', 5, 1),
(2, 2, 2, '2018-01-09 08:30:00', '405В', 5, 1),
(3, 3, 3, '2018-01-11 09:00:00', '102В', 5, 1),
(4, 4, 4, '2018-01-14 08:00:00', '202С', 5, 1),
(5, 5, 5, '2018-01-16 09:30:00', '102А', 5, 1),
(6, 6, 6, '2018-01-18 08:00:00', '202А', 5, 1),
(7, 4, 7, '2018-01-21 08:00:00', '202В', 5, 1),
(8, 7, 8, '2018-01-23 08:30:00', '102С', 5, 1),
(9, 8, 9, '2018-01-25 08:30:00', '202А', 5, 1),
(10, 6, 10, '2018-01-28 08:00:00', '202С', 5, 1),
(11, 1, 1, '2018-02-04 09:30:00', '102А', 5, 2),
(12, 2, 2, '2018-02-06 08:00:00', '102В', 5, 2),
(13, 3, 3, '2017-11-08 09:00:00', '102С', 5, 2),
(14, 4, 4, '2018-02-11 08:00:00', '202А', 5, 2),
(15, 5, 5, '2018-02-13 09:30:00', '202В', 5, 2),
(16, 6, 6, '2018-02-15 08:30:00', '202С', 5, 2),
(17, 4, 7, '2018-02-18 08:00:00', '102А', 5, 2),
(18, 7, 8, '2018-02-20 08:00:00', '102В', 5, 2),
(19, 8, 9, '2018-02-22 08:00:00', '102С', 5, 2),
(20, 6, 10, '2018-02-25 08:30:00', '202А', 5, 2),
(21, 1, 1, '2018-06-03 08:00:00', '102А', 10, 3),
(22, 2, 2, '2018-06-05 08:00:00', '102В', 10, 3),
(23, 3, 3, '2018-06-07 08:00:00', '102С', 10, 3),
(24, 4, 4, '2018-06-10 08:00:00', '202А', 10, 3),
(25, 5, 5, '2018-06-12 08:00:00', '202В', 10, 3),
(26, 6, 6, '2018-06-14 08:00:00', '202С', 10, 3),
(27, 4, 7, '2018-06-17 08:00:00', '202А', 10, 3),
(28, 7, 8, '2018-06-19 08:00:00', '202В', 10, 3),
(29, 8, 9, '2018-06-21 08:00:00', '202С', 10, 3),
(30, 6, 10, '2018-06-24 08:00:00', '102А', 10, 3);

-- --------------------------------------------------------

--
-- Table structure for table `exams_students`
--

CREATE TABLE `exams_students` (
  `id_exam` int(11) NOT NULL,
  `id_student` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exams_students`
--

INSERT INTO `exams_students` (`id_exam`, `id_student`) VALUES
(5, 3),
(1, 3),
(2, 3),
(3, 3),
(1, 1),
(1, 2),
(2, 2),
(3, 2),
(1, 4),
(2, 4),
(4, 4),
(3, 4),
(1, 7),
(2, 7),
(3, 7),
(4, 7);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `faculty` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `faculty`) VALUES
(1, 'Математика и информатика'),
(2, 'Информатика'),
(3, 'Компютърни науки');

-- --------------------------------------------------------

--
-- Table structure for table `lecturers`
--

CREATE TABLE `lecturers` (
  `id` int(11) NOT NULL,
  `first_name` varchar(256) NOT NULL,
  `surname` varchar(256) NOT NULL,
  `last_name` varchar(256) NOT NULL,
  `id_degree` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lecturers`
--

INSERT INTO `lecturers` (`id`, `first_name`, `surname`, `last_name`, `id_degree`) VALUES
(1, 'Маргарита', 'Иванова', 'Тодорова', 2),
(2, 'Димирът', 'Петков', 'Петров', 1),
(3, 'Георги', 'Симеонов', 'Тодоров', 1),
(4, 'Милен', 'Стоянов', 'Христов', 2),
(5, 'Христо', 'Паскалев', 'Тужаров', 1),
(6, 'Златко', 'Пламенов', 'Върбанов', 2),
(7, 'Валентин', 'Борисов', 'Бакоев', 1),
(8, 'Стефка', 'Златева', 'Буюклиева', 2);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `first_name` varchar(256) NOT NULL,
  `surname` varchar(256) NOT NULL,
  `last_name` varchar(256) NOT NULL,
  `id_faculty` int(11) NOT NULL,
  `faculty_number` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `surname`, `last_name`, `id_faculty`, `faculty_number`, `username`, `password`) VALUES
(1, 'Димитър', 'Иванов', 'Георгиев', 1, '13271', 'chazzy', '$2y$10$GIQ8OxE.y9vPm35N4hZWr.SDxTGxsa1G04/QUR5r4.u1LMmeP.Rd6'),
(2, 'Даниела', 'Иванова', 'Георгиева', 1, '13272', 'dancheto', '$2y$10$zJx2e83E166ywvx5XjX.neowcX//3mnQYJHZ/Gd1LUBU9ajWQiKwO'),
(3, 'Иван', 'Димитров', 'Георгиев', 1, '13274', 'gatakka', '$2y$10$wGce7p2JbzuWuPG5ODYpC.h5zU43cXWdgvowfg3sKMK.eqps5ha9e'),
(4, 'Гергана', 'Симеонова', 'Иванова', 1, '13275', 'gercho', '$2y$10$zCSw68gYkdq7rLYCJb75s.Nv2dJNxgdtJl974VXeX8oSXKDiawB32'),
(5, 'Георги', 'Иванов', 'Димитров', 1, '13276', 'gogo132', '$2y$10$K/LFLV.F57pvS8pR8AmhD.Ih.Pjzdh84hqFPnJBvE1Pc3MBonzHGK'),
(6, 'Ивелина', 'Георгиева', 'Христова', 2, '13380', 'ivalina', '$2y$10$MgiM/B4Wg1cHE5A1cdRTheKiKWnXu8rqZgx7eh0FX8ZyzQ.qvAIYa'),
(7, 'Христо', 'Иванов', 'Стоянов', 2, '13381', 'itsaka', '$2y$10$z90LxsPX6xOsuMiK4inUl.PvoaOZJAfOnPdoT.XotPFNtEccu0GdG'),
(8, 'Деница', 'Борисова', 'Паскалева', 2, '13383', 'denitsa', '$2y$10$053tkM4uA85QNWUDY/zaquoOPTCg35MutXok2lTN0EkGHWbkrWMra'),
(9, 'Стоян', 'Христов', 'Иванов', 2, '13384', 'stoicho', '$2y$10$hFX.beOuoeFKuCYAyZuYz.nCm7qcAakXd/1afge7kcgLKKIrQ3zui'),
(10, 'Иванка', 'Хистова', 'Христова', 2, '13386', 'vanichka', '$2y$10$gmI/u5XWRnUAcafd9D7Ftuenyy51CVE.7klGxS8Dvs1qzjhBkaeay'),
(11, 'Борис', 'Симеонов', 'Христов', 3, '13465', 'bborisov', '$2y$10$9JKsoHg7COHGz04dyuqequ..BGxVmbmz18V1aCb.9sLjveDP5S8Ci'),
(12, 'Симеон', 'Христов', 'Борисов', 3, '13466', 'simeon', '$2y$10$vcbfx3qtEcTHsoy35O0IC.8TDPgst0uCEvNGbv/joRvGXoXwlryLi'),
(13, 'Веселина', 'Маринова', 'Бешева', 3, '13467', 'veselinka', '$2y$10$MVS5GLl02YDQXsTD9wny8uN.axnDJR12i3U7HaQD6qJDh4xyDG36C'),
(14, 'Марина', 'Димитрова', 'Косева', 3, '13468', 'marina', '$2y$10$IPCvDIetZ.BLnZ6O//w1A.IdwXB.EGyO7rdZbLPiRWgtWdNeI77Au'),
(15, 'Радостина', 'Цветанова', 'Гърбева', 3, '13469', 'radostche', '$2y$10$jU8eXB/87umbRSD5rQEByuFZtYMqz2TVPdYwm6iOfiwckTb7h7Zba');

-- --------------------------------------------------------

--
-- Table structure for table `type_exam`
--

CREATE TABLE `type_exam` (
  `id` int(11) NOT NULL,
  `type_exam` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type_exam`
--

INSERT INTO `type_exam` (`id`, `type_exam`) VALUES
(1, 'редовен'),
(2, 'поправителен'),
(3, 'ликвидация');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `degree`
--
ALTER TABLE `degree`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discipline`
--
ALTER TABLE `discipline`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecturers`
--
ALTER TABLE `lecturers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type_exam`
--
ALTER TABLE `type_exam`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `degree`
--
ALTER TABLE `degree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `discipline`
--
ALTER TABLE `discipline`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `lecturers`
--
ALTER TABLE `lecturers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `type_exam`
--
ALTER TABLE `type_exam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
